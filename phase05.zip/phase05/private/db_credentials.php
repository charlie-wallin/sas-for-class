<?php
// local
// define("DB_SERVER", "localhost");
// define("DB_USER", "sally");
// define("DB_PASS", "P@ssword1234");
// define("DB_NAME", "salamanders");

// SiteGround
define("DB_SERVER", "localhost");
define("DB_USER", "ulpmyxg7g6b7a");
define("DB_PASS", "P@ssword1234-4321");
define("DB_NAME", "dbnywkxx35sncd");
